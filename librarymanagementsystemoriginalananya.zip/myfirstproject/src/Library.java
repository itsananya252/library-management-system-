import java.util.*;
public class Library {
    private ArrayList<Book> books = new ArrayList<>();
    private Scanner sc = new Scanner(System.in);
    public void addBook() {
        System.out.print("Enter Book Title: ");
        String title = sc.nextLine();
        System.out.print("Enter Author Name: ");
        String author = sc.nextLine();
        System.out.print("Enter Book ID: ");
        String bookID = sc.nextLine();

        books.add(new Book(title, author, bookID));
        System.out.println("✅ Book added successfully.");
    }
    public void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("❌ No books available.");
        } else {
            for (Book b : books) {
                b.displayDetails();
            }
        }
    }
    public void searchBook() {
        System.out.print("Search by title or author: ");
        String key = sc.nextLine().toLowerCase();

        boolean found = false;
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(key) || b.getAuthor().toLowerCase().contains(key)) {
                b.displayDetails();
                found = true;
            }
        }
        if (!found) {
            System.out.println("❌ No matching book found.");
        }
    }

    public void issueBook() {
        System.out.print("Enter Book ID to issue: ");
        String id = sc.nextLine();

        for (Book b : books) {
            if (b.getBookID().equals(id)) {
                if (!b.isIssued()) {
                    b.issueBook();
                    System.out.println("✅ Book issued successfully.");
                } else {
                    System.out.println("⚠️ Book already issued.");
                }
                return;
            }
        }
        System.out.println("❌ Book not found.");
    }
    public void returnBook() {
        System.out.print("Enter Book ID to return: ");
        String id = sc.nextLine();

        for (Book b : books) {
            if (b.getBookID().equals(id)) {
                if (b.isIssued()) {
                    b.returnBook();
                    System.out.println("✅ Book returned successfully.");
                } else {
                    System.out.println("⚠️ Book was not issued.");
                }
                return;
            }
        }
        System.out.println("❌ Book not found.");
    }
}
