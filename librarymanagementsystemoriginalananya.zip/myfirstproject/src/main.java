import java.util.Scanner;
class Main {
        public static void main(String[] args) {
            Library library = new Library();
            Scanner sc = new Scanner(System.in);
            int choice;

            do {
                System.out.println("\n===== Library Management System =====");
                System.out.println("1. Add Book");
                System.out.println("2. View Books");
                System.out.println("3. Search Book");
                System.out.println("4. Issue Book");
                System.out.println("5. Return Book");
                System.out.println("6. Exit");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                sc.nextLine();  // consume newline

                switch (choice) {
                    case 1 -> library.addBook();
                    case 2 -> library.viewBooks();
                    case 3 -> library.searchBook();
                    case 4 -> library.issueBook();
                    case 5 -> library.returnBook();
                    case 6 -> System.out.println("👋 Exiting...");
                    default -> System.out.println("❌ Invalid choice.");
                }
            } while (choice != 6);
        }
    }

