class Book {
    private String title;
    private String author;
    private String bookID;
    private boolean isIssued;
    public Book(String title, String author, String bookID) {
        this.title = title;
        this.author = author;
        this.bookID = bookID;
        this.isIssued = false;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public String getBookID() {
        return bookID;
    }
    public boolean isIssued() {
        return isIssued;
    }
    public void issueBook() {
        this.isIssued = true;
    }
    public void returnBook() {
        this.isIssued = false;
    }
    public void displayDetails() {
        System.out.println("Book ID: " + bookID + ", Title: " + title + ", Author: " + author + ", Issued: " + isIssued);
    }
}
